/* ************************************ */
/*                                      */
/* *vc_strncmp                          */
/*                                      */
/* By: Yukako, Alex, Juan               */
/*                                      */
/* ************************************ */

#include <stdio.h>

int vc_strncmp(char *s1, char *s2, unsigned int n)
{
    int a = 0;
    int b = 0;

    a = s1[n];
    b = s2[n];

    if (a < b)
    {
        return -1;
    }
    else if (a > b)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
