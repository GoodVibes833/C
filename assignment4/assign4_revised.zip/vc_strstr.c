/* ************************************ */
/*                                      */
/* *vc_strstr                           */
/*                                      */
/* By: Amanda, Alex, Juan               */
/*                                      */
/* ************************************ */

#include <stdio.h>
#include <string.h>

char *vc_strstr(char *str, char *to_find)
{
    int i;
    int j;
    int k;

    if (*to_find == '\0')
    {
        return str;
    }
    else
    {
        for (i = 0; *(str + i) != '\0'; i++)
        {
            if (*(str + i) == *to_find)
            {
                for (j = i, k = 0; *(str + j) == *(to_find + k); j++, k++)
                    ;
                if (*(to_find + k) == '\0')
                    return str + i;
            }
        }
        return NULL;
    }
}
