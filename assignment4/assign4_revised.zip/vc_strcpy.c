/* ************************************ */
/*                                      */
/* *vc_strcpy                           */
/*                                      */
/* By: Yukako, Alex, Juan               */
/*                                      */
/* ************************************ */
#include <stdio.h>

char *vc_strcpy(char *dest, char *src)
{
    for (int i = 0; src[i] != '\0'; i++)
    {
        dest[i] = src[i];
    }
    return dest;
};
