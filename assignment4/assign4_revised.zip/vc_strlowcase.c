/* ************************************ */
/*                                      */
/* *vc_strlowcase                       */
/*                                      */
/* By: Yukako, Alex, Juan               */
/*                                      */
/* ************************************ */
#include <stdio.h>

char *vc_strlowcase(char *str)
{
    while (*str != '\0')
    {
        if (*str < 91)
        {
            *str = *str + 32;
            putchar(*str);
            str++;
        }
        else
        {
            putchar(*str);
            str++;
        }
    }

    return str;
};
