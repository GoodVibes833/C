/* ************************************ */
/*                                      */
/* *vc_strupcase                        */
/*                                      */
/* By: Amanda, Alex, Juan               */
/*                                      */
/* ************************************ */
#include <stdio.h>

char *vc_strupcase(char *str)
{
    while (*str != '\0')
    {
        if (*str > 96)
        {
            *str = *str - 32;
            putchar(*str);
            str++;
        }
        else
        {
            putchar(*str);
            str++;
        }
    }

    return str;
};
